import UIKit

//cau 1 Viết hàm để check số đã nhập có phải là số có các chữ số tăng dần hay không
func cau1(n:Int)->Void{
    let arr:String = String(n)
    let result = Int(String(arr.sorted()))
    if result == n{
        print("YES")
    }else{
        print("NO")
    }
    
}
cau1(n: 56789)

var s:[String] = ["1","1","2","3"]
//cau2 Viet ham check số đã nhập có chữ số nào lặp lại nhiều nhất
func cau2(n:Int)->Int{
    let arr:String = String(n)
    var arrStr:[String] = []
    for i in 0..<arr.count{
        let index = arr.index(arr.startIndex,offsetBy: i)
        arrStr.append(String(arr[index]))
    }
    arrStr.sort()
    var dem = 0
    var arrDem:[Int] = []
    for i in 0..<arrStr.count-1{
        var j = arrStr.count-1
        while j >= 0{
            if arrStr[i] == arrStr[j] {
                dem += 1
            }
        j -= 1
        }
        arrDem.append(dem)
        dem = 0
    }
    arrDem
    var max = arrDem[0]
    var vitri = 0
    for i in 1..<arrDem.count-1{
        if arrDem[i] > max{
            max = arrDem[i]
            vitri = i
        }
    }
    let index = arrStr.index(arrStr.startIndex,offsetBy: vitri)
    let result:Int = Int(String(arrStr[index]))!
    
    return result
}

var t2 = cau2(n: 12322)

//cau3 viết hàm in ra từ có số kí tự nhiều nhất
func cau3(n:String)->String{
    let str:String = n
    let str1 = str.split(separator: " ")
    if str1.count == 0{
        return "chuoi rong"
    }
    var max:Int = str1[0].count
    var result:String = ""
    for i in 1..<str1.count{
        if str1[i].count > max{
            max = str1[i].count
            result = String(str1[i])
        }
    }
    
    return result
}
var t = cau3(n: "   ")
//cau 4: viet ham check sô tự nhiên vừa nhập có phải số mà chỉ cần đôit chỗ 2 số sẽ thành sôs tự nhiên tăng dần không
func cau4 (n:Int) {
    var nhap = n
    var arr : [Int] = []
    while (nhap > 0){
        arr.append(nhap % 10)
        nhap /= 10
    }
    var dem = 0
    arr.reverse()
    let arrSort = arr.sorted()
    for i in 0 ..< arr.count {
        if arr[i] != arrSort[i] {
            dem += 1
        }
    }
    if dem == 2 {
        print("YES")
    }else {
     print("NO")
    }
}
cau4(n: 42313)

//cau 5: viết hàm biến số vừa nhập thành số chẵn có giá trị lớn nhất
func cau5(n:Int)->Int{
    let str:String = String(n)
    var array:[String] = []
    for i in 0..<str.count{
        let index = str.index(str.startIndex,offsetBy: i)
        array.append(String(str[index]))
    }
    array.sort()
    array.reverse()
    var i = 1
    while i < array.count {
        if Int(array[array.endIndex-1])! % 2==0{
            break;
        }else{
            let swap = array[array.endIndex-1]
            array[array.endIndex-1] = array[array.endIndex-i-1]
            array[array.endIndex-i-1] = swap
             i += 1
        }
    }
    var r1:String = String()
    for i in array{
        r1 += i
    }
    var result:Int = 0
    result = Int(String(r1))!
    return result
    
}

var t5 = cau5(n: 3344)


var int:Int = 2
var arrint:[Int] = [1,1]
var str:String = "99"
var arrstr:[String] = ["12","12"]
str.count



